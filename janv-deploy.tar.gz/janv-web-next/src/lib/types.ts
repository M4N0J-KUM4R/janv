// ── Enums ──────────────────────────────────────────────────

export type UserRole = 'SuperAdmin' | 'Faculty' | 'Student';
export type QuestionType = 'Mcq' | 'MultiSelect' | 'TrueFalse' | 'Coding';
export type Difficulty = 'Easy' | 'Medium' | 'Hard';
export type AttemptStatus = 'InProgress' | 'Submitted' | 'Graded';

// ── Core Models ────────────────────────────────────────────

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  avatar_url?: string;
  is_active: boolean;
  department?: string;
  institution_id?: string;
  batch?: string;
  class?: string;
  created_at: string;
  updated_at: string;
}

export interface Institution {
  id: string;
  name: string;
  code: string;
  logo_url?: string;
  is_active: boolean;
  created_at: string;
}

export interface Assessment {
  id: string;
  title: string;
  description?: string;
  course_id: string;
  faculty_id: string;
  duration_mins: number;
  total_marks: number;
  pass_percentage: number;
  is_published: boolean;
  shuffle_questions: boolean;
  show_results: boolean;
  start_time?: string;
  end_time?: string;
  test_code?: string;
  status?: string;
  num_sections?: number;
  tab_switches_allowed?: number;
  instructions?: string;
  institution_visibility?: string[];
  batch_visibility?: string[];
  question_count?: number;
  created_at: string;
}

export interface Question {
  id: string;
  bank_id?: string;
  question_type: QuestionType;
  content: string;
  options?: QuestionOption[];
  explanation?: string;
  difficulty: Difficulty;
  tags?: string[];
  points: number;
  created_at: string;
}

export interface QuestionOption {
  text: string;
  is_correct?: boolean;
}

export interface QuestionBank {
  id: string;
  title: string;
  subject?: string;
  faculty_id: string;
  created_at: string;
}

export interface Attempt {
  id: string;
  assessment_id: string;
  student_id: string;
  started_at: string;
  submitted_at?: string;
  score?: number;
  total_marks: number;
  percentage?: number;
  is_passed?: boolean;
  answers?: Record<string, unknown>;
  status: AttemptStatus;
}

export interface AssessmentTemplate {
  id: string;
  title: string;
  description?: string;
  category?: string;
  duration_mins: number;
  total_marks: number;
  pass_percentage: number;
  shuffle_questions: boolean;
  show_results: boolean;
  question_config?: Record<string, unknown>;
  faculty_id: string;
  is_public: boolean;
  created_at: string;
}

export interface LeaderboardRow {
  rank: number;
  student_id: string;
  student_name: string;
  score: number;
  total_marks: number;
  percentage: number;
  time_taken_secs?: number;
  completed_at?: string;
}

export interface Faq {
  id: string;
  question: string;
  answer: string;
  category?: string;
  sort_order: number;
  is_published: boolean;
  created_at: string;
}

// ── Dashboard / Analytics ──────────────────────────────────

export interface FacultyDashboardStats {
  total_students: number;
  current_rating: number;
  total_assessments: number;
  total_attempts: number;
  avg_score: number;
  pass_rate: number;
}

// Legacy alias
export type DashboardStats = FacultyDashboardStats;

export type AssessmentStatus = 'Draft' | 'Scheduled' | 'Ongoing' | 'Completed' | 'Cancelled';

export interface AssessmentAnalytics {
  assessment_id: string;
  total_attempts: number;
  avg_score: number;
  highest_score: number;
  lowest_score: number;
  pass_rate: number;
  score_distribution: ScoreBucket[];
}

export interface ScoreBucket {
  range: string;
  count: number;
}

// ── API Response Wrappers ──────────────────────────────────

export interface PaginatedResponse<T> {
  data: T[];
  page: number;
  per_page: number;
  total: number;
}

export interface AttemptStartResponse {
  attempt: Attempt;
  questions: Question[];
  duration_mins: number;
  total_marks: number;
  resumed: boolean;
}

export interface AttemptSubmitResponse {
  attempt: Attempt;
  score: number;
  total_marks: number;
  percentage: number;
  is_passed: boolean;
  time_taken_secs: number;
  show_results: boolean;
  graded_answers?: GradedAnswer[];
}

export interface GradedAnswer {
  question_id: string;
  student_answer: unknown;
  is_correct: boolean;
  points_earned: number;
  points_possible: number;
}

export interface TimerResponse {
  remaining_seconds: number;
  elapsed_seconds: number;
  total_seconds: number;
  expired: boolean;
  status: string;
}

// ── Request Types ──────────────────────────────────────────

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  email: string;
  password: string;
  full_name: string;
  role?: UserRole;
}

export interface CreateAssessmentRequest {
  title: string;
  description?: string;
  course_id: string;
  duration_mins: number;
  total_marks: number;
  pass_percentage: number;
  shuffle_questions: boolean;
  show_results: boolean;
  start_time?: string;
  end_time?: string;
}

export interface CreateQuestionRequest {
  question_type: QuestionType;
  content: string;
  options?: QuestionOption[];
  explanation?: string;
  difficulty: Difficulty;
  tags?: string[];
  points: number;
}
