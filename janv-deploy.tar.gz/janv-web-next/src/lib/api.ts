import type {
  Assessment,
  Attempt,
  AttemptStartResponse,
  AttemptSubmitResponse,
  AssessmentTemplate,
  LeaderboardRow,
  Faq,
  FacultyDashboardStats,
  AssessmentAnalytics,
  TimerResponse,
  User,
  QuestionBank,
  PaginatedResponse,
} from './types';

const API_BASE = '/api';

class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function request<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const token = typeof window !== 'undefined' ? localStorage.getItem('access_token') : null;

  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({ message: res.statusText }));
    throw new ApiError(body.message || body.error || 'Request failed', res.status);
  }

  return res.json();
}

// ── Auth ────────────────────────────────────────────────────

export const auth = {
  login: (email: string, password: string) =>
    request<{ access_token: string; refresh_token: string; user: User }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  register: (data: { email: string; password: string; full_name: string; role?: string }) =>
    request<{ access_token: string; user: User }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  me: () => request<User>('/auth/me'),

  refresh: (refresh_token: string) =>
    request<{ access_token: string }>('/auth/refresh', {
      method: 'POST',
      body: JSON.stringify({ refresh_token }),
    }),
};

// ── Assessments ─────────────────────────────────────────────

export const assessments = {
  list: (params?: { page?: number; per_page?: number; course_id?: string; is_published?: boolean }) => {
    const query = new URLSearchParams();
    if (params?.page) query.set('page', String(params.page));
    if (params?.per_page) query.set('per_page', String(params.per_page));
    if (params?.course_id) query.set('course_id', params.course_id);
    if (params?.is_published !== undefined) query.set('is_published', String(params.is_published));
    return request<PaginatedResponse<Assessment>>(`/assessments?${query}`);
  },

  get: (id: string) =>
    request<{ assessment: Assessment; questions: unknown[]; question_count: number }>(`/assessments/${id}`),

  create: (data: Partial<Assessment>) =>
    request<Assessment>('/assessments', { method: 'POST', body: JSON.stringify(data) }),

  update: (id: string, data: Partial<Assessment>) =>
    request<Assessment>(`/assessments/${id}`, { method: 'PUT', body: JSON.stringify(data) }),

  delete: (id: string) =>
    request<{ status: string }>(`/assessments/${id}`, { method: 'DELETE' }),

  publish: (id: string) =>
    request<Assessment>(`/assessments/${id}/publish`, { method: 'POST' }),

  duplicate: (id: string, new_title?: string) =>
    request<Assessment>(`/assessments/${id}/duplicate`, {
      method: 'POST',
      body: JSON.stringify({ new_title }),
    }),

  // Questions
  addQuestions: (assessmentId: string, questionIds: string[]) =>
    request(`/assessments/${assessmentId}/questions`, {
      method: 'POST',
      body: JSON.stringify({ question_ids: questionIds }),
    }),

  // Attempts
  start: (id: string) =>
    request<AttemptStartResponse>(`/assessments/${id}/start`, { method: 'POST' }),

  submitAttempt: (attemptId: string, answers: Record<string, unknown>) =>
    request<AttemptSubmitResponse>(`/assessments/attempts/${attemptId}/submit`, {
      method: 'POST',
      body: JSON.stringify({ answers }),
    }),

  getAttempt: (attemptId: string) =>
    request<{ attempt: Attempt; assessment_title: string }>(`/assessments/attempts/${attemptId}`),

  myAttempts: () =>
    request<Attempt[]>('/assessments/my-attempts'),

  // Timer
  checkTimer: (attemptId: string) =>
    request<TimerResponse>(`/assessments/attempts/${attemptId}/timer`),

  // Analytics
  analytics: (id: string) =>
    request<AssessmentAnalytics>(`/assessments/${id}/analytics`),

  // Leaderboard
  leaderboard: (id: string, page?: number) => {
    const query = page ? `?page=${page}` : '';
    return request<{ leaderboard: LeaderboardRow[]; total: number }>(`/assessments/${id}/leaderboard${query}`);
  },

  globalLeaderboard: (page?: number) => {
    const query = page ? `?page=${page}` : '';
    return request<{ leaderboard: unknown[] }>(`/assessments/leaderboard/global${query}`);
  },

  // Passcode
  setPasscode: (id: string, passcode: string) =>
    request(`/assessments/${id}/passcode`, {
      method: 'POST',
      body: JSON.stringify({ passcode }),
    }),

  verifyPasscode: (passcode: string) =>
    request<{ valid: boolean; assessment_id: string }>('/assessments/passcode/verify', {
      method: 'POST',
      body: JSON.stringify({ passcode }),
    }),
};

// ── Templates ───────────────────────────────────────────────

export const templates = {
  list: () => request<AssessmentTemplate[]>('/assessments/templates'),

  create: (data: Partial<AssessmentTemplate>) =>
    request<AssessmentTemplate>('/assessments/templates', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  createFrom: (data: { template_id: string; course_id: string; title?: string }) =>
    request('/assessments/templates/create-from', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  saveAs: (assessmentId: string) =>
    request<AssessmentTemplate>(`/assessments/${assessmentId}/save-as-template`, { method: 'POST' }),
};

// ── Question Banks ──────────────────────────────────────────

export const questionBanks = {
  list: () => request<QuestionBank[]>('/assessments/banks'),

  create: (data: { title: string; subject?: string }) =>
    request<QuestionBank>('/assessments/banks', { method: 'POST', body: JSON.stringify(data) }),

  addQuestion: (bankId: string, data: unknown) =>
    request(`/assessments/banks/${bankId}/questions`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),
};

// ── Analytics / Dashboard ───────────────────────────────────

export const analytics = {
  dashboard: () => request<FacultyDashboardStats>('/analytics/dashboard'),

  studentProgress: () => request('/analytics/student/progress'),

  studentStreak: () => request('/analytics/student/streak'),

  faqs: () => request<Faq[]>('/analytics/faqs'),
};

// ── Admin ───────────────────────────────────────────────────

export const admin = {
  searchStudents: (query: string) => {
    const params = new URLSearchParams({ search: query });
    return request<{ data: User[] }>(`/admin/users?${params}`);
  },
};
