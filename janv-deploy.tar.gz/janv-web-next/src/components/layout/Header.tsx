'use client';

import { useAuth } from '@/lib/auth';

export default function Header() {
  const { user, logout } = useAuth();

  return (
    <header className="header">
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <button
          style={{
            background: 'none',
            border: 'none',
            fontSize: '1.2rem',
            cursor: 'pointer',
            color: 'var(--text-secondary)',
            padding: '4px',
          }}
          title="Toggle Sidebar"
        >
          ≡
        </button>
      </div>

      <div className="header-institution">
        Sri Venkateswara College Of Engineering & Technology, Chittoor | Vaibhav Ayush Raj | Associate Professor
      </div>

      <div className="header-user" onClick={logout} title="Click to logout">
        <div className="header-user-email">
          {user?.email || 'Ayush7369@gmail.com'}
        </div>
        <span style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>▼</span>
      </div>
    </header>
  );
}
