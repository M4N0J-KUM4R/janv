'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

import {
  IconDashboard,
  IconReports,
  IconDownload,
  IconSearch,
  IconPlus,
  IconTests,
  IconTemplate,
  IconKey,
  IconFaq,
  IconTrophy,
  IconCertificate,
} from '@/components/common/Icons';

const sections = [
  {
    title: 'LEARNING',
    items: [
      { label: 'Dashboard', href: '/learn/dashboard', icon: <IconDashboard /> },
      { label: 'View Reports', href: '/learn/overallReport', icon: <IconReports /> },
      { label: 'Download Reports', href: '/learn/customReport', icon: <IconDownload /> },
      { label: 'Search Student', href: '/learn/search', icon: <IconSearch /> },
    ],
  },
  {
    title: 'ASSESSMENTS',
    items: [
      { label: 'Create Test', href: '/assessments/create', icon: <IconPlus /> },
      { label: 'My Tests', href: '/assessments', icon: <IconTests /> },
      { label: 'Create from Template', href: '/assessments/templates', icon: <IconTemplate /> },
      { label: 'Pass Code', href: '/passcode', icon: <IconKey /> },
      { label: 'FAQs', href: '/faqs', icon: <IconFaq /> },
      { label: 'Leaderboard', href: '/leaderboard', icon: <IconTrophy /> },
    ],
  },
  {
    title: 'CERTIFICATES',
    items: [
      { label: 'View Certificates Report', href: '/certificates', icon: <IconCertificate /> },
      { label: 'Download Certificate Report', href: '/certificates/download', icon: <IconDownload /> },
    ],
  },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <div className="logo-icon" style={{ background: '#00C853', color: '#ffffff', borderRadius: '50%', fontWeight: 800 }}>P</div>
        <span style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: '1.2rem', color: '#1a1a1a' }}>PrepInsta</span>
      </div>

      {sections.map((section) => (
        <div key={section.title} className="sidebar-section">
          <div className="sidebar-section-title">{section.title}</div>
          <ul className="sidebar-nav">
            {section.items.map((item) => {
              const isActive =
                item.href === '/'
                  ? pathname === '/'
                  : pathname.startsWith(item.href);
              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className={`sidebar-link ${isActive ? 'active' : ''}`}
                  >
                    <span className="icon">{item.icon}</span>
                    {item.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </aside>
  );
}
