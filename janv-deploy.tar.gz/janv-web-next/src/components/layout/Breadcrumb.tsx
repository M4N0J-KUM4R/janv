'use client';

import Link from 'next/link';

interface BreadcrumbItem {
  label: string;
  href?: string;
}

export default function Breadcrumb({ items }: { items: BreadcrumbItem[] }) {
  return (
    <nav className="breadcrumb">
      {items.map((item, idx) => {
        const isLast = idx === items.length - 1;
        return (
          <span key={idx} style={{ display: 'inline-flex', alignItems: 'center', gap: '8px' }}>
            {idx > 0 && <span className="breadcrumb-sep">&gt;</span>}
            {item.href && !isLast ? (
              <Link href={item.href} className="breadcrumb-item">
                {item.label}
              </Link>
            ) : (
              <span className={`breadcrumb-item ${isLast ? 'active' : ''}`}>{item.label}</span>
            )}
          </span>
        );
      })}
    </nav>
  );
}
