'use client';

import React, { useRef } from 'react';

interface RichTextEditorProps {
  value: string;
  onChange: (val: string) => void;
  placeholder?: string;
  minHeight?: string;
}

export default function RichTextEditor({
  value,
  onChange,
  placeholder = 'Write content here...',
  minHeight = '140px',
}: RichTextEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);

  const format = (cmd: string, arg?: string) => {
    document.execCommand(cmd, false, arg);
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const handleInput = () => {
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const insertFormula = () => {
    const formula = prompt('Enter LaTeX formula (e.g. \\frac{a}{b} or E = mc^2):');
    if (formula) {
      format('insertHTML', `<span class="katex" style="font-family: KaTeX_Main, serif; font-style: italic; color: #2563eb; background: #eff6ff; padding: 2px 6px; border-radius: 4px;">$${formula}$</span>&nbsp;`);
    }
  };

  const insertLink = () => {
    const url = prompt('Enter URL:');
    if (url) {
      format('createLink', url);
    }
  };

  return (
    <div className="ql-snow" style={{ border: '1px solid #d1d5db', borderRadius: '8px', overflow: 'hidden', background: '#ffffff' }}>
      {/* Quill Toolbar */}
      <div className="ql-toolbar ql-snow" style={{ border: 'none', borderBottom: '1px solid #e5e7eb', background: '#f9fafb', padding: '6px 10px', display: 'flex', flexWrap: 'wrap', gap: '4px', alignItems: 'center' }}>
        <span className="ql-formats" style={{ display: 'inline-flex', gap: '2px' }}>
          <button type="button" title="Bold" onClick={() => format('bold')} style={{ fontWeight: 'bold', width: '28px', height: '28px', border: '1px solid #e5e7eb', borderRadius: '4px', background: '#fff', cursor: 'pointer' }}>B</button>
          <button type="button" title="Italic" onClick={() => format('italic')} style={{ fontStyle: 'italic', width: '28px', height: '28px', border: '1px solid #e5e7eb', borderRadius: '4px', background: '#fff', cursor: 'pointer' }}>I</button>
          <button type="button" title="Underline" onClick={() => format('underline')} style={{ textDecoration: 'underline', width: '28px', height: '28px', border: '1px solid #e5e7eb', borderRadius: '4px', background: '#fff', cursor: 'pointer' }}>U</button>
          <button type="button" title="Strikethrough" onClick={() => format('strikeThrough')} style={{ textDecoration: 'line-through', width: '28px', height: '28px', border: '1px solid #e5e7eb', borderRadius: '4px', background: '#fff', cursor: 'pointer' }}>S</button>
        </span>

        <span style={{ width: '1px', height: '20px', background: '#e5e7eb', margin: '0 4px' }} />

        <span className="ql-formats" style={{ display: 'inline-flex', gap: '2px' }}>
          <button type="button" title="Heading 1" onClick={() => format('formatBlock', '<h1>')} style={{ fontSize: '12px', fontWeight: 700, padding: '0 6px', height: '28px', border: '1px solid #e5e7eb', borderRadius: '4px', background: '#fff', cursor: 'pointer' }}>H1</button>
          <button type="button" title="Heading 2" onClick={() => format('formatBlock', '<h2>')} style={{ fontSize: '12px', fontWeight: 600, padding: '0 6px', height: '28px', border: '1px solid #e5e7eb', borderRadius: '4px', background: '#fff', cursor: 'pointer' }}>H2</button>
          <button type="button" title="Normal" onClick={() => format('formatBlock', '<p>')} style={{ fontSize: '11px', padding: '0 6px', height: '28px', border: '1px solid #e5e7eb', borderRadius: '4px', background: '#fff', cursor: 'pointer' }}>P</button>
        </span>

        <span style={{ width: '1px', height: '20px', background: '#e5e7eb', margin: '0 4px' }} />

        <span className="ql-formats" style={{ display: 'inline-flex', gap: '2px' }}>
          <button type="button" title="Numbered List" onClick={() => format('insertOrderedList')} style={{ width: '28px', height: '28px', border: '1px solid #e5e7eb', borderRadius: '4px', background: '#fff', cursor: 'pointer' }}>1.</button>
          <button type="button" title="Bullet List" onClick={() => format('insertUnorderedList')} style={{ width: '28px', height: '28px', border: '1px solid #e5e7eb', borderRadius: '4px', background: '#fff', cursor: 'pointer' }}>•</button>
        </span>

        <span style={{ width: '1px', height: '20px', background: '#e5e7eb', margin: '0 4px' }} />

        <span className="ql-formats" style={{ display: 'inline-flex', gap: '2px' }}>
          <button type="button" title="Formula (LaTeX)" onClick={insertFormula} style={{ fontSize: '12px', fontWeight: 700, color: '#2563eb', padding: '0 6px', height: '28px', border: '1px solid #dbeafe', borderRadius: '4px', background: '#eff6ff', cursor: 'pointer' }}>f(x)</button>
          <button type="button" title="Insert Link" onClick={insertLink} style={{ fontSize: '12px', padding: '0 6px', height: '28px', border: '1px solid #e5e7eb', borderRadius: '4px', background: '#fff', cursor: 'pointer' }}>🔗</button>
          <button type="button" title="Clear Formatting" onClick={() => format('removeFormat')} style={{ fontSize: '12px', color: '#6b7280', padding: '0 6px', height: '28px', border: '1px solid #e5e7eb', borderRadius: '4px', background: '#fff', cursor: 'pointer' }}>Clear</button>
        </span>
      </div>

      {/* Editor Content Area */}
      <div className="ql-container ql-snow" style={{ border: 'none' }}>
        <div
          ref={editorRef}
          className="ql-editor"
          contentEditable
          suppressContentEditableWarning
          onInput={handleInput}
          style={{
            minHeight,
            padding: '12px 16px',
            outline: 'none',
            fontSize: '14px',
            color: '#1f2937',
            lineHeight: '1.6',
          }}
          dangerouslySetInnerHTML={{ __html: value }}
          data-placeholder={placeholder}
        />
      </div>
    </div>
  );
}
