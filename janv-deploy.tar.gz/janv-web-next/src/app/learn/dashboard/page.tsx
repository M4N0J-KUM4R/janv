'use client';

import { useEffect, useState } from 'react';
import Breadcrumb from '@/components/layout/Breadcrumb';
import { analytics } from '@/lib/api';
import type { FacultyDashboardStats } from '@/lib/types';

export default function DashboardPage() {
  const [stats, setStats] = useState<FacultyDashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    analytics
      .dashboard()
      .then((data) => setStats(data))
      .catch(() => {
        // Fallback demo data matching original PrepInsta dashboard
        setStats({
          total_students: 3434,
          current_rating: 5,
          total_assessments: 42,
          total_attempts: 100886,
          avg_score: 85.5,
          pass_rate: 92.4,
        });
      })
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <Breadcrumb items={[{ label: 'Learning' }, { label: 'Dashboard', href: '/learn/dashboard' }]} />

      <div className="stats-grid">
        <div className="stat-card">
          <div>
            <div className="stat-card__label">Total Students</div>
            <div className="stat-card__value">
              {loading ? '...' : stats?.total_students || 3434}
            </div>
          </div>
          <img src="/icons/totalStudentsIcon.svg" alt="Total Students" style={{ width: '48px', height: '49px' }} />
        </div>

        <div className="stat-card">
          <div>
            <div className="stat-card__label">Current Student Rating</div>
            <div className="stat-card__value">
              {stats?.current_rating || 5} <img src="/icons/Star.svg" alt="Star" style={{ width: '22px', height: '22px', marginLeft: '6px', verticalAlign: 'middle' }} />
            </div>
          </div>
          <img src="/icons/studentRatingIcon.svg" alt="Student Rating" style={{ width: '48px', height: '49px' }} />
        </div>

        <div className="stat-card">
          <div>
            <div className="stat-card__label">Total Videos Watched</div>
            <div className="stat-card__value">
              {loading ? '...' : stats?.total_attempts || 100886}
            </div>
          </div>
          <img src="/icons/totalVideosWatched.svg" alt="Total Videos Watched" style={{ width: '48px', height: '49px' }} />
        </div>
      </div>

      <div className="stats-grid stats-grid--two">
        <div className="stat-card">
          <div>
            <div className="stat-card__label">Total watch time (mins)</div>
            <div className="stat-card__value">1361686</div>
          </div>
          <img src="/icons/watchTimeIcon.svg" alt="Watch Time" style={{ width: '48px', height: '49px' }} />
        </div>

        <div className="stat-card">
          <div>
            <div className="stat-card__label">Most Watched Courses</div>
            <div
              style={{
                fontSize: '1rem',
                fontWeight: 700,
                marginTop: '8px',
                lineHeight: 1.4,
                color: 'var(--text-primary)',
              }}
            >
              Python, Quantitative Aptitude, C Programming, Full Stack Web development MERN Stack, SQL
            </div>
          </div>
          <img src="/icons/mostWatchedIcon.svg" alt="Most Watched Courses" style={{ width: '48px', height: '49px' }} />
        </div>
      </div>
    </div>
  );
}
