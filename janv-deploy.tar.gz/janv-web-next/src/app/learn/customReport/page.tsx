'use client';

import { useState } from 'react';
import Breadcrumb from '@/components/layout/Breadcrumb';

interface DownloadHistory {
  id: string;
  date: string;
  batch: string;
  branch: string;
  course: string;
  status: 'Processing' | 'Completed';
  progress: number;
}

export default function DownloadReportsPage() {
  const [batch, setBatch] = useState('');
  const [branch, setBranch] = useState('');
  const [course, setCourse] = useState('');
  const [history, setHistory] = useState<DownloadHistory[]>([]);
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownload = () => {
    if (!batch) return;

    setIsDownloading(true);
    const newId = Date.now().toString();
    const newDownload: DownloadHistory = {
      id: newId,
      date: new Date().toLocaleString(),
      batch,
      branch: branch || 'All',
      course: course || 'All',
      status: 'Processing',
      progress: 0,
    };

    setHistory((prev) => [newDownload, ...prev]);

    // Simulate download progress
    let currentProgress = 0;
    const interval = setInterval(() => {
      currentProgress += 20;
      setHistory((prev) =>
        prev.map((item) =>
          item.id === newId
            ? {
                ...item,
                progress: currentProgress,
                status: currentProgress >= 100 ? 'Completed' : 'Processing',
              }
            : item
        )
      );

      if (currentProgress >= 100) {
        clearInterval(interval);
        setIsDownloading(false);
      }
    }, 500);
  };

  return (
    <div>
      <Breadcrumb items={[{ label: 'Learning' }, { label: 'Download Report', href: '/learn/customReport' }]} />

      <h1 className="page-title" style={{ fontSize: '1.25rem', fontWeight: 700, margin: '32px 0 16px' }}>Download Report</h1>

      <div className="card" style={{ marginBottom: '24px' }}>
        <div className="card-body">
          <div className="filter-row">
            <div className="form-group">
              <label className="form-label">
                <span className="required">*</span> Batch
              </label>
              <select
                className="form-select"
                value={batch}
                onChange={(e) => setBatch(e.target.value)}
              >
                <option value="">Select Batch</option>
                <option value="2026">2026 Batch</option>
                <option value="2027">2027 Batch</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Branch</label>
              <select
                className="form-select"
                value={branch}
                onChange={(e) => setBranch(e.target.value)}
              >
                <option value="">Select Branch</option>
                <option value="CSE">Computer Science</option>
                <option value="ECE">Electronics</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Course</label>
              <select
                className="form-select"
                value={course}
                onChange={(e) => setCourse(e.target.value)}
              >
                <option value="">Select Course</option>
                <option value="Python">Python</option>
                <option value="SQL">SQL</option>
              </select>
            </div>
          </div>

          <button
            className="btn btn--secondary"
            disabled={!batch || isDownloading}
            onClick={handleDownload}
            style={{
              background: batch && !isDownloading ? '#6c757d' : '#e5e7eb',
              color: batch && !isDownloading ? 'white' : '#9ca3af',
              marginTop: '16px',
            }}
          >
            {isDownloading ? 'Processing...' : 'Download Report'}
          </button>
        </div>
      </div>

      <div className="card">
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>DATE & TIME</th>
                <th>BATCH</th>
                <th>BRANCH</th>
                <th>COURSE</th>
                <th>STATUS</th>
                <th>DOWNLOAD PROGRESS</th>
                <th>REPORT</th>
              </tr>
            </thead>
            <tbody>
              {history.length === 0 ? (
                <tr>
                  <td colSpan={7} className="empty-state" style={{ padding: '30px', textAlign: 'center' }}>
                    No reports generated yet
                  </td>
                </tr>
              ) : (
                history.map((item) => (
                  <tr key={item.id}>
                    <td>{item.date}</td>
                    <td>{item.batch}</td>
                    <td>{item.branch}</td>
                    <td>{item.course}</td>
                    <td>
                      <span
                        style={{
                          color: item.status === 'Completed' ? 'var(--success)' : 'var(--warning)',
                          fontWeight: 600,
                        }}
                      >
                        {item.status}
                      </span>
                    </td>
                    <td>
                      <div style={{ width: '100%', backgroundColor: '#e5e7eb', borderRadius: '9999px', height: '8px' }}>
                        <div
                          style={{
                            width: `${item.progress}%`,
                            backgroundColor: item.status === 'Completed' ? 'var(--success)' : 'var(--brand-accent)',
                            height: '100%',
                            borderRadius: '9999px',
                            transition: 'width 0.3s ease',
                          }}
                        />
                      </div>
                    </td>
                    <td>
                      <button
                        className="btn btn--secondary btn--sm"
                        disabled={item.status !== 'Completed'}
                      >
                        Download
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
