'use client';

import { useState } from 'react';
import Breadcrumb from '@/components/layout/Breadcrumb';
import { admin } from '@/lib/api';
import type { User } from '@/lib/types';

export default function ViewReportsPage() {
  const [batch, setBatch] = useState('');
  const [branch, setBranch] = useState('');
  const [course, setCourse] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<User[] | null>(null);

  const handleSearch = async () => {
    setLoading(true);
    try {
      const res = await admin.searchStudents(batch || branch || course || '');
      setResults(res.data);
    } catch (e) {
      // Fallback demo data
      setResults([
        {
          id: '1',
          full_name: 'Priya Sharma',
          email: 'priya.sharma@example.com',
          role: 'Student',
          is_active: true,
          institution_id: 'inst_1',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
        {
          id: '2',
          full_name: 'Rahul Verma',
          email: 'rahul.verma@example.com',
          role: 'Student',
          is_active: true,
          institution_id: 'inst_1',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <Breadcrumb items={[{ label: 'Learning' }, { label: 'View Report', href: '/learn/overallReport' }]} />

      {/* Top Stats Grid */}
      <div className="stats-grid">
        <div className="stat-card">
          <div>
            <div className="stat-card__label">Total Students</div>
            <div className="stat-card__value">3434</div>
          </div>
          <img src="/icons/totalStudentsIcon.svg" alt="Total Students" style={{ width: '48px', height: '49px' }} />
        </div>

        <div className="stat-card">
          <div>
            <div className="stat-card__label">Current Student Rating</div>
            <div className="stat-card__value">
              5 <img src="/icons/Star.svg" alt="Star" style={{ width: '22px', height: '22px', marginLeft: '6px', verticalAlign: 'middle' }} />
            </div>
          </div>
          <img src="/icons/studentRatingIcon.svg" alt="Student Rating" style={{ width: '48px', height: '49px' }} />
        </div>

        <div className="stat-card">
          <div>
            <div className="stat-card__label">Total Videos Watched</div>
            <div className="stat-card__value">100886</div>
          </div>
          <img src="/icons/totalVideosWatched.svg" alt="Total Videos Watched" style={{ width: '48px', height: '49px' }} />
        </div>
      </div>

      <div className="stats-grid stats-grid--two">
        <div className="stat-card">
          <div>
            <div className="stat-card__label">Total watch time (mins)</div>
            <div className="stat-card__value">1361686</div>
          </div>
          <img src="/icons/watchTimeIcon.svg" alt="Watch Time" style={{ width: '48px', height: '49px' }} />
        </div>

        <div className="stat-card">
          <div>
            <div className="stat-card__label">Most Watched Courses</div>
            <div
              style={{
                fontSize: '1rem',
                fontWeight: 700,
                marginTop: '8px',
                lineHeight: 1.4,
              }}
            >
              Python, Quantitative Aptitude, C Programming, Full Stack Web development MERN Stack, SQL
            </div>
          </div>
          <img src="/icons/mostWatchedIcon.svg" alt="Most Watched Courses" style={{ width: '48px', height: '49px' }} />
        </div>
      </div>

      {/* View Report Filter Section */}
      <h2 style={{ fontSize: '1.25rem', fontWeight: 700, margin: '32px 0 16px' }}>View Report</h2>

      <div className="card" style={{ marginBottom: '24px' }}>
        <div className="card-body">
          <div className="filter-row">
            <div className="form-group">
              <label className="form-label">
                <span className="required">*</span> Batch
              </label>
              <select
                className="form-select"
                value={batch}
                onChange={(e) => setBatch(e.target.value)}
              >
                <option value="">Batch</option>
                <option value="2026">2026 Batch</option>
                <option value="2027">2027 Batch</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Branch</label>
              <select
                className="form-select"
                value={branch}
                onChange={(e) => setBranch(e.target.value)}
              >
                <option value="">Branch</option>
                <option value="CSE">Computer Science & Engineering</option>
                <option value="ECE">Electronics & Communication</option>
                <option value="EEE">Electrical & Electronics</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Course</label>
              <select
                className="form-select"
                value={course}
                onChange={(e) => setCourse(e.target.value)}
              >
                <option value="">Course</option>
                <option value="Python">Python Programming</option>
                <option value="DSA">Data Structures & Algorithms</option>
                <option value="Aptitude">Quantitative Aptitude</option>
              </select>
            </div>

            <button
              className="btn btn--secondary"
              onClick={handleSearch}
              disabled={loading}
              style={{
                background: '#6c757d',
                color: 'white',
                minWidth: '100px',
                height: '42px',
              }}
            >
              {loading ? 'Searching...' : 'Search'}
            </button>
          </div>
        </div>
      </div>

      {/* Results Table */}
      {results && (
        <div className="card">
          <div className="card-body" style={{ padding: 0 }}>
            <div className="table-responsive">
              <table className="table">
                <thead>
                  <tr>
                    <th>S.No</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Course</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {results.length === 0 ? (
                    <tr>
                      <td colSpan={6} style={{ textAlign: 'center', padding: '32px' }}>
                        No records found
                      </td>
                    </tr>
                  ) : (
                    results.map((student, i) => (
                      <tr key={student.id}>
                        <td>{i + 1}</td>
                        <td>{student.full_name}</td>
                        <td>{student.email}</td>
                        <td style={{ textTransform: 'capitalize' }}>{student.role}</td>
                        <td>{course || 'N/A'}</td>
                        <td>
                          <button className="btn btn--secondary btn--sm">View Details</button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
