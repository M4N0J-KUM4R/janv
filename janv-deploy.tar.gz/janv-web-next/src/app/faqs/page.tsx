'use client';

import { useEffect, useState } from 'react';
import Breadcrumb from '@/components/layout/Breadcrumb';
import { analytics } from '@/lib/api';
import type { Faq } from '@/lib/types';

export default function FaqsPage() {
  const [faqs, setFaqs] = useState<Faq[]>([]);
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  useEffect(() => {
    analytics
      .faqs()
      .then(setFaqs)
      .catch(() => {
        setFaqs([
          {
            id: '1',
            question: 'How do I start a passcode-protected test?',
            answer: 'Navigate to "Pass Code" in the sidebar menu under Assessments, enter the 8-character code provided by your professor, and click "Unlock Test".',
            sort_order: 1,
            is_published: true,
            created_at: '',
          },
          {
            id: '2',
            question: 'What happens if I switch tabs during an ongoing assessment?',
            answer: 'The system monitors tab switches. You have a maximum allowed threshold (usually 10 tab switches). Exceeding this limit will automatically submit your attempt.',
            sort_order: 2,
            is_published: true,
            created_at: '',
          },
          {
            id: '3',
            question: 'When can I see my score and performance report?',
            answer: 'If the faculty enabled "Show performance report", your score, question-by-question breakdown, and correct answers will be visible immediately after submission.',
            sort_order: 3,
            is_published: true,
            created_at: '',
          },
        ]);
      });
  }, []);

  return (
    <div>
      <Breadcrumb items={[{ label: 'Assessments' }, { label: 'FAQs', href: '/faqs' }]} />

      <h1 className="page-title">Frequently Asked Questions</h1>
      <p className="page-subtitle">Find answers to common questions about tests, grading, and platform policies.</p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', maxWidth: '800px' }}>
        {faqs.map((faq, idx) => (
          <div key={faq.id || idx} className="card">
            <div
              className="card-header"
              style={{ cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
              onClick={() => setOpenIdx(openIdx === idx ? null : idx)}
            >
              <span>{faq.question}</span>
              <span>{openIdx === idx ? '▲' : '▼'}</span>
            </div>
            {openIdx === idx && (
              <div className="card-body" style={{ color: 'var(--text-secondary)', lineHeight: 1.6 }}>
                {faq.answer}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
