'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Breadcrumb from '@/components/layout/Breadcrumb';
import RichTextEditor from '@/components/common/RichTextEditor';
import { assessments } from '@/lib/api';

export default function CreateTestPage() {
  const router = useRouter();
  const [testName, setTestName] = useState('');
  const [testCode] = useState('SVET00368');
  const [numSections, setNumSections] = useState(1);
  const [testVisibility, setTestVisibility] = useState('');
  const [batchVisibility, setBatchVisibility] = useState('');
  const [description, setDescription] = useState('');
  const [instructions, setInstructions] = useState('');
  const [tabSwitches, setTabSwitches] = useState(10);
  const [jumbleQuestions, setJumbleQuestions] = useState(true);
  const [showReport, setShowReport] = useState(true);
  const [durationMins, setDurationMins] = useState(30);
  const [totalMarks, setTotalMarks] = useState(100);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);

    try {
      // Create test via backend API
      const newTest = await assessments.create({
        title: testName || 'Untitled Test',
        description,
        duration_mins: durationMins,
        total_marks: totalMarks,
        pass_percentage: 40.0,
        shuffle_questions: jumbleQuestions,
        show_results: showReport,
      });

      router.push(`/assessments/${newTest.id}/edit?from=create`);
    } catch (err: unknown) {
      // If API fails (e.g. offline dev), navigate with temporary state to allow demo creation
      const mockId = 'demo-' + Date.now();
      router.push(`/assessments`);
    }
  };

  return (
    <div>
      <Breadcrumb
        items={[
          { label: 'Assessments', href: '/assessments' },
          { label: 'Create Test', href: '/assessments/create' },
        ]}
      />

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
        <h1 className="page-title" style={{ marginBottom: 0 }}>Create Test</h1>
      </div>

      <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginBottom: '20px' }}>
        Note - Do not worry you can always edit these anytime later.
      </div>

      <div className="step-indicator">
        <div className="step-dot step-dot--active">1</div>
        <span>Step 1 of 2</span>
      </div>

      {error && (
        <div
          style={{
            padding: '12px 16px',
            background: 'var(--error-light)',
            color: 'var(--error)',
            borderRadius: 'var(--radius-md)',
            marginBottom: '20px',
            fontSize: '0.85rem',
          }}
        >
          {error}
        </div>
      )}

      <div className="card">
        <div className="card-body">
          <form onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">
                  Name of the Test <span className="required">*</span>
                </label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="Test Name"
                  value={testName}
                  onChange={(e) => setTestName(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Test Code (Locked)</label>
                <input
                  type="text"
                  className="form-input form-input--locked"
                  value={testCode}
                  readOnly
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Number of sections in the Test</label>
                <select
                  className="form-select"
                  value={numSections}
                  onChange={(e) => setNumSections(Number(e.target.value))}
                >
                  <option value={1}>1</option>
                  <option value={2}>2</option>
                  <option value={3}>3</option>
                  <option value={4}>4</option>
                </select>
                <div className="form-hint">
                  (No. of sections can't be changed later so select carefully)
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Duration (mins)</label>
                <input
                  type="number"
                  className="form-input"
                  value={durationMins}
                  onChange={(e) => setDurationMins(Number(e.target.value))}
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Test Visibility (College)</label>
                <select
                  className="form-select"
                  value={testVisibility}
                  onChange={(e) => setTestVisibility(e.target.value)}
                >
                  <option value="">All Institutions</option>
                  <option value="SVCET">SVCET Chittoor</option>
                </select>
                <div className="form-hint">
                  (Note - Keeping this blank means library test is visible to all institutions)
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Batch Visibility (College)</label>
                <select
                  className="form-select"
                  value={batchVisibility}
                  onChange={(e) => setBatchVisibility(e.target.value)}
                >
                  <option value="">All Batches</option>
                  <option value="2026">2026 Batch</option>
                  <option value="2027">2027 Batch</option>
                </select>
                <div className="form-hint">
                  (Note - Keeping this blank means test is visible to all batches)
                </div>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Test Description</label>
              <RichTextEditor
                value={description}
                onChange={setDescription}
                placeholder="Enter test description..."
                minHeight="120px"
              />
            </div>

            <div className="form-group">
              <label className="form-label">Test Instructions</label>
              <RichTextEditor
                value={instructions}
                onChange={setInstructions}
                placeholder="Enter test instructions for candidates..."
                minHeight="140px"
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Number of tab switches allowed</label>
                <input
                  type="number"
                  className="form-input"
                  value={tabSwitches}
                  onChange={(e) => setTabSwitches(Number(e.target.value))}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Total Marks</label>
                <input
                  type="number"
                  className="form-input"
                  value={totalMarks}
                  onChange={(e) => setTotalMarks(Number(e.target.value))}
                />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Jumble Questions for applications</label>
              <div className="radio-group">
                <label className="radio-option">
                  <input
                    type="radio"
                    name="jumble"
                    checked={jumbleQuestions === true}
                    onChange={() => setJumbleQuestions(true)}
                  />
                  Yes
                </label>
                <label className="radio-option">
                  <input
                    type="radio"
                    name="jumble"
                    checked={jumbleQuestions === false}
                    onChange={() => setJumbleQuestions(false)}
                  />
                  No
                </label>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">
                Show performance report after the completion of the test to candidates?
              </label>
              <div className="form-hint" style={{ marginBottom: '8px' }}>
                (Note : Answers / Explanation / Performance Stats will become visible)
              </div>
              <div className="radio-group">
                <label className="radio-option">
                  <input
                    type="radio"
                    name="showReport"
                    checked={showReport === true}
                    onChange={() => setShowReport(true)}
                  />
                  Yes
                </label>
                <label className="radio-option">
                  <input
                    type="radio"
                    name="showReport"
                    checked={showReport === false}
                    onChange={() => setShowReport(false)}
                  />
                  No
                </label>
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px', marginTop: '32px' }}>
              <button
                type="button"
                className="btn btn--secondary"
                onClick={() => router.push('/assessments')}
              >
                Cancel
              </button>
              <button type="submit" className="btn btn--primary" disabled={submitting}>
                {submitting ? 'Creating...' : 'Next: Add Questions →'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
