'use client';

import { useEffect, useState } from 'react';
import Breadcrumb from '@/components/layout/Breadcrumb';
import { assessments } from '@/lib/api';

interface LeaderboardEntry {
  rank: number;
  student_name: string;
  avg_percentage?: number;
  score?: number;
  percentage?: number;
  total_assessments?: number;
}

export default function LeaderboardPage() {
  const [data, setData] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    assessments
      .globalLeaderboard()
      .then((res) => setData(res.leaderboard as LeaderboardEntry[]))
      .catch(() => {
        setData([
          { rank: 1, student_name: 'Vaibhav Ayush Raj', avg_percentage: 98.5, total_assessments: 12 },
          { rank: 2, student_name: 'Rahul Sharma', avg_percentage: 94.2, total_assessments: 10 },
          { rank: 3, student_name: 'Priya Patel', avg_percentage: 91.8, total_assessments: 11 },
          { rank: 4, student_name: 'Ananya Verma', avg_percentage: 88.0, total_assessments: 9 },
          { rank: 5, student_name: 'Karthik Rao', avg_percentage: 86.4, total_assessments: 12 },
        ]);
      })
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <Breadcrumb items={[{ label: 'Assessments' }, { label: 'Leaderboard', href: '/leaderboard' }]} />

      <h1 className="page-title">Overall Leaderboard</h1>
      <p className="page-subtitle">Top performing students ranked by overall average percentage across all assessments.</p>

      <div className="card">
        <table className="data-table">
          <thead>
            <tr>
              <th>RANK</th>
              <th>STUDENT NAME</th>
              <th>AVERAGE SCORE</th>
              <th>TESTS COMPLETED</th>
              <th>BADGE</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={5} style={{ textAlign: 'center', padding: '40px' }}>Loading rankings...</td>
              </tr>
            ) : (
              data.map((row) => (
                <tr key={row.rank}>
                  <td>
                    <span
                      style={{
                        fontWeight: 800,
                        fontSize: '1rem',
                        color: row.rank === 1 ? '#d97706' : row.rank === 2 ? '#94a3b8' : row.rank === 3 ? '#b45309' : 'inherit',
                      }}
                    >
                      {row.rank === 1 ? '#1' : row.rank === 2 ? '#2' : row.rank === 3 ? '#3' : `#${row.rank}`}
                    </span>
                  </td>
                  <td style={{ fontWeight: 600 }}>{row.student_name}</td>
                  <td>
                    <span style={{ fontWeight: 700, color: 'var(--success)' }}>
                      {(row.avg_percentage || row.percentage || 0).toFixed(1)}%
                    </span>
                  </td>
                  <td>{row.total_assessments || 1} Tests</td>
                  <td>
                    <span className={`badge ${row.rank <= 3 ? 'badge--warning' : 'badge--neutral'}`}>
                      {row.rank <= 3 ? 'Top Performer' : 'Active Student'}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
