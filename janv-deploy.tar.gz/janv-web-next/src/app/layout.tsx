import './globals.css';
import { AuthProvider } from '@/lib/auth';
import Sidebar from '@/components/layout/Sidebar';
import Header from '@/components/layout/Header';

export const metadata = {
  title: 'Janv — PrepInsta Assessment Platform',
  description: 'Comprehensive Assessment & Learning Service built with Rust & Next.js',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <AuthProvider>
          <div className="app-layout">
            <Sidebar />
            <Header />
            <main className="main-content">
              <div className="page-container">{children}</div>
            </main>
          </div>
        </AuthProvider>
      </body>
    </html>
  );
}
