use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use uuid::Uuid;
use validator::Validate;

use crate::models::{Difficulty, QuestionType};

#[derive(Debug, Deserialize, Validate)]
pub struct CreateAssessmentRequest {
    #[validate(length(min = 3))]
    pub title: String,
    pub description: Option<String>,
    pub course_id: Uuid,
    pub duration_mins: i32,
    pub total_marks: i32,
    pub pass_percentage: f64,
    pub is_published: bool,
    pub shuffle_questions: bool,
    pub show_results: bool,
    pub start_time: Option<DateTime<Utc>>,
    pub end_time: Option<DateTime<Utc>>,
}

#[derive(Debug, Deserialize, Validate)]
pub struct UpdateAssessmentRequest {
    pub title: Option<String>,
    pub description: Option<String>,
    pub duration_mins: Option<i32>,
    pub total_marks: Option<i32>,
    pub pass_percentage: Option<f64>,
    pub is_published: Option<bool>,
    pub shuffle_questions: Option<bool>,
    pub show_results: Option<bool>,
    pub start_time: Option<DateTime<Utc>>,
    pub end_time: Option<DateTime<Utc>>,
}

#[derive(Debug, Deserialize, Validate)]
pub struct CreateQuestionRequest {
    pub bank_id: Option<Uuid>,
    pub question_type: QuestionType,
    #[validate(length(min = 1))]
    pub content: String,
    pub options: Option<serde_json::Value>,
    pub explanation: Option<String>,
    pub difficulty: Difficulty,
    pub tags: Option<Vec<String>>,
    pub points: i32,
}

#[derive(Debug, Deserialize, Validate)]
pub struct UpdateQuestionRequest {
    pub question_type: Option<QuestionType>,
    pub content: Option<String>,
    pub options: Option<serde_json::Value>,
    pub explanation: Option<String>,
    pub difficulty: Option<Difficulty>,
    pub tags: Option<Vec<String>>,
    pub points: Option<i32>,
}

#[derive(Debug, Deserialize, Validate)]
pub struct CreateQuestionBankRequest {
    #[validate(length(min = 3))]
    pub title: String,
    pub subject: Option<String>,
}

#[derive(Debug, Deserialize, Validate)]
pub struct SubmitAttemptRequest {
    pub answers: serde_json::Value,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct AttemptResponse {
    pub id: Uuid,
    pub assessment_id: Uuid,
    pub score: Option<f64>,
    pub total_marks: i32,
    pub percentage: Option<f64>,
    pub is_passed: Option<bool>,
    pub status: String,
    pub submitted_at: Option<DateTime<Utc>>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct AddQuestionsRequest {
    pub question_ids: Vec<Uuid>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct AssessmentListQuery {
    pub page: Option<u32>,
    pub per_page: Option<u32>,
    pub course_id: Option<Uuid>,
    pub is_published: Option<bool>,
}

// ── Template DTOs ──────────────────────────────────────────

#[derive(Debug, Deserialize, Validate)]
pub struct CreateTemplateRequest {
    #[validate(length(min = 3))]
    pub title: String,
    pub description: Option<String>,
    pub category: Option<String>,
    pub duration_mins: i32,
    pub total_marks: i32,
    pub pass_percentage: f64,
    pub shuffle_questions: bool,
    pub show_results: bool,
    pub question_config: Option<serde_json::Value>,
    pub is_public: bool,
}

#[derive(Debug, Deserialize)]
pub struct CreateFromTemplateRequest {
    pub template_id: Uuid,
    pub course_id: Uuid,
    pub title: Option<String>,
    pub start_time: Option<DateTime<Utc>>,
    pub end_time: Option<DateTime<Utc>>,
}

// ── Passcode DTOs ──────────────────────────────────────────

#[derive(Debug, Deserialize, Validate)]
pub struct SetPasscodeRequest {
    #[validate(length(min = 4, max = 20))]
    pub passcode: String,
}

#[derive(Debug, Deserialize, Validate)]
pub struct VerifyPasscodeRequest {
    pub passcode: String,
}

#[derive(Debug, Serialize)]
pub struct PasscodeVerifyResponse {
    pub valid: bool,
    pub assessment_id: Uuid,
}

// ── Leaderboard DTOs ───────────────────────────────────────

#[derive(Debug, Serialize, Deserialize)]
pub struct LeaderboardQuery {
    pub page: Option<u32>,
    pub per_page: Option<u32>,
}

#[derive(Debug, Serialize)]
pub struct LeaderboardRow {
    pub rank: i32,
    pub student_id: Uuid,
    pub student_name: String,
    pub score: f64,
    pub total_marks: i32,
    pub percentage: f64,
    pub time_taken_secs: Option<i32>,
    pub completed_at: Option<DateTime<Utc>>,
}

// ── Dashboard / Analytics DTOs ─────────────────────────────

#[derive(Debug, Serialize)]
pub struct FacultyDashboardStats {
    pub total_students: i64,
    pub current_rating: f64,
    pub total_assessments: i64,
    pub total_attempts: i64,
    pub avg_score: f64,
    pub pass_rate: f64,
}

#[derive(Debug, Serialize)]
pub struct AssessmentAnalyticsResponse {
    pub assessment_id: Uuid,
    pub total_attempts: i64,
    pub avg_score: f64,
    pub highest_score: f64,
    pub lowest_score: f64,
    pub pass_rate: f64,
    pub score_distribution: Vec<ScoreBucket>,
}

#[derive(Debug, Serialize)]
pub struct ScoreBucket {
    pub range: String,
    pub count: i64,
}

// ── FAQ DTOs ───────────────────────────────────────────────

#[derive(Debug, Deserialize, Validate)]
pub struct CreateFaqRequest {
    #[validate(length(min = 5))]
    pub question: String,
    #[validate(length(min = 5))]
    pub answer: String,
    pub category: Option<String>,
    pub sort_order: Option<i32>,
}

// ── Duplicate Assessment ───────────────────────────────────

#[derive(Debug, Deserialize)]
pub struct DuplicateAssessmentRequest {
    pub new_title: Option<String>,
}

