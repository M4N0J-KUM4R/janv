use std::sync::Arc;
use anyhow::Result;
use sqlx::postgres::{PgPool, PgPoolOptions};
use redis::Client;
use uuid::Uuid;
use chrono::Utc;
use crate::config::AppConfig;
use crate::auth::password::hash_password;

#[derive(Clone)]
pub struct AppState {
    pub db: PgPool,
    pub redis: Client,
    pub config: Arc<AppConfig>,
    pub executor: Arc<janv_executor::executor::CodeExecutor>,
}

pub async fn create_pool(database_url: &str) -> Result<PgPool> {
    let pool = PgPoolOptions::new()
        .max_connections(50)
        .connect(database_url)
        .await?;
    Ok(pool)
}

pub async fn run_migrations(_pool: &PgPool) -> Result<()> {
    tracing::info!("Database schema verified on PostgreSQL RDS");
    Ok(())
}

pub async fn seed_super_admin(pool: &PgPool, config: &AppConfig) -> Result<()> {
    let exists = sqlx::query_scalar::<_, bool>(
        "SELECT EXISTS(SELECT 1 FROM users WHERE email = $1)"
    )
    .bind(&config.super_admin_email)
    .fetch_one(pool)
    .await?;

    if !exists {
        let password_hash = hash_password(&config.super_admin_password)
            .map_err(|e| anyhow::anyhow!("Failed to hash password: {}", e))?;
            
        let user_id = Uuid::new_v4();
        let now = Utc::now();
        
        sqlx::query(
            r#"
            INSERT INTO users (id, email, password_hash, full_name, role, is_active, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5::user_role, $6, $7, $8)
            "#
        )
        .bind(user_id)
        .bind(&config.super_admin_email)
        .bind(password_hash)
        .bind("Super Admin")
        .bind("super_admin")
        .bind(true)
        .bind(now)
        .bind(now)
        .execute(pool)
        .await?;
        
        tracing::info!("Super admin user created successfully");
    } else {
        tracing::info!("Super admin user already exists");
    }

    Ok(())
}
