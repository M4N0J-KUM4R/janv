use axum::{extract::State, Json, response::IntoResponse, Extension};
use janv_common::{dto::*, errors::AppError, models::*};
use crate::{db::AppState, auth::middleware::AuthUser};

pub async fn get_leaderboard(
    State(state): State<AppState>,
    Extension(user): Extension<AuthUser>,
) -> Result<impl IntoResponse, AppError> {
    Ok(Json(serde_json::json!([
        {"user_id": "dummy", "score": 100}
    ])))
}
