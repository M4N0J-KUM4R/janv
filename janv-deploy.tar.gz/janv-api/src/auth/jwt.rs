use chrono::{Utc, Duration};
use jsonwebtoken::{decode, encode, DecodingKey, EncodingKey, Header, Validation};
use serde::{Deserialize, Serialize};
use uuid::Uuid;
use janv_common::errors::AppError;
use janv_common::models::User;

#[derive(Debug, Serialize, Deserialize)]
pub struct Claims {
    pub sub: Uuid,
    pub email: String,
    pub role: String,
    pub exp: usize,
    pub iat: usize,
}

pub fn create_access_token(user: &User, secret: &str, expires_secs: u64) -> Result<String, AppError> {
    let now = Utc::now();
    let exp = (now + Duration::seconds(expires_secs as i64)).timestamp() as usize;
    let iat = now.timestamp() as usize;

    let claims = Claims {
        sub: user.id,
        email: user.email.clone(),
        // Convert the role directly to a string. Assuming UserRole implements Display or Serialize
        role: serde_json::to_string(&user.role).unwrap_or_default().trim_matches('"').to_string(),
        exp,
        iat,
    };

    encode(
        &Header::default(),
        &claims,
        &EncodingKey::from_secret(secret.as_bytes()),
    )
    .map_err(|_| AppError::InternalError("Failed to create access token".to_string()))
}

pub fn create_refresh_token(user: &User, secret: &str, expires_secs: u64) -> Result<String, AppError> {
    let now = Utc::now();
    let exp = (now + Duration::seconds(expires_secs as i64)).timestamp() as usize;
    let iat = now.timestamp() as usize;

    let claims = Claims {
        sub: user.id,
        email: user.email.clone(),
        role: serde_json::to_string(&user.role).unwrap_or_default().trim_matches('"').to_string(),
        exp,
        iat,
    };

    encode(
        &Header::default(),
        &claims,
        &EncodingKey::from_secret(secret.as_bytes()),
    )
    .map_err(|_| AppError::InternalError("Failed to create refresh token".to_string()))
}

pub fn verify_token(token: &str, secret: &str) -> Result<Claims, AppError> {
    let token_data = decode::<Claims>(
        token,
        &DecodingKey::from_secret(secret.as_bytes()),
        &Validation::default(),
    )
    .map_err(|_| AppError::Unauthorized("Invalid or expired token".to_string()))?;

    Ok(token_data.claims)
}

#[cfg(test)]
mod tests {
    use super::*;
    use janv_common::models::UserRole;
    use uuid::Uuid;

    #[test]
    fn test_jwt_generation_and_verification() {
        let user = User {
            id: Uuid::new_v4(),
            email: "test@janv.dev".to_string(),
            password_hash: "secret_hash".to_string(),
            full_name: "Test User".to_string(),
            role: UserRole::Student,
            avatar_url: None,
            is_active: true,
            department: Some("CS".to_string()),
            institution_id: None,
            created_at: Utc::now(),
            updated_at: Utc::now(),
        };

        let secret = "very-long-secret-key-that-is-at-least-32-bytes-long-for-testing-purposes";
        let token = create_access_token(&user, secret, 3600).expect("Access token creation failed");
        
        let claims = verify_token(&token, secret).expect("Token verification failed");
        assert_eq!(claims.sub, user.id);
        assert_eq!(claims.email, user.email);
        assert_eq!(claims.role, "Student");
    }
}
