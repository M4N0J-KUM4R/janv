use crate::db::AppState;
use axum::{routing::get, extract::State, Json, response::IntoResponse, Router};
use janv_common::{dto::*, errors::AppError, models::*};
use crate::auth::middleware::AuthUser;

pub fn router() -> Router<AppState> {
    Router::new()
        .route("/dashboard", get(dashboard_stats))
        .route("/student/progress", get(student_progress))
        .route("/student/streak", get(student_streak))
        .route("/faqs", get(list_faqs))
}

pub async fn dashboard_stats(
    State(state): State<AppState>,
    user: AuthUser,
) -> Result<impl IntoResponse, AppError> {
    let total_students: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM users WHERE role = 'student'"
    )
    .fetch_one(&state.db)
    .await?;

    let total_assessments: (i64,) = match user.role {
        UserRole::Faculty => {
            sqlx::query_as("SELECT COUNT(*) FROM assessments WHERE faculty_id = $1")
                .bind(user.id)
                .fetch_one(&state.db)
                .await?
        }
        _ => {
            sqlx::query_as("SELECT COUNT(*) FROM assessments")
                .fetch_one(&state.db)
                .await?
        }
    };

    let total_attempts: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM attempts WHERE status != 'in_progress'"
    )
    .fetch_one(&state.db)
    .await?;

    let avg_score: (Option<f64>,) = sqlx::query_as(
        "SELECT AVG(percentage) FROM attempts WHERE status != 'in_progress' AND percentage IS NOT NULL"
    )
    .fetch_one(&state.db)
    .await?;

    let passed: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM attempts WHERE is_passed = true"
    )
    .fetch_one(&state.db)
    .await?;

    let pass_rate = if total_attempts.0 > 0 {
        (passed.0 as f64 / total_attempts.0 as f64) * 100.0
    } else {
        0.0
    };

    Ok(Json(FacultyDashboardStats {
        total_students: total_students.0,
        current_rating: 5.0, // Could be calculated from student feedback
        total_assessments: total_assessments.0,
        total_attempts: total_attempts.0,
        avg_score: avg_score.0.unwrap_or(0.0),
        pass_rate,
    }))
}

pub async fn student_progress(
    State(state): State<AppState>,
    user: AuthUser,
) -> Result<impl IntoResponse, AppError> {
    let problems_solved: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM code_submissions WHERE student_id = $1 AND status = 'accepted'"
    )
    .bind(user.id)
    .fetch_one(&state.db)
    .await?;

    let assessments_taken: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM attempts WHERE student_id = $1 AND status != 'in_progress'"
    )
    .bind(user.id)
    .fetch_one(&state.db)
    .await?;

    let avg_score: (Option<f64>,) = sqlx::query_as(
        "SELECT AVG(percentage) FROM attempts WHERE student_id = $1 AND status != 'in_progress' AND percentage IS NOT NULL"
    )
    .bind(user.id)
    .fetch_one(&state.db)
    .await?;

    Ok(Json(serde_json::json!({
        "student_id": user.id,
        "problems_solved": problems_solved.0,
        "assessments_taken": assessments_taken.0,
        "avg_score": avg_score.0.unwrap_or(0.0)
    })))
}

pub async fn student_streak(
    State(state): State<AppState>,
    user: AuthUser,
) -> Result<impl IntoResponse, AppError> {
    // Count distinct days with activity (submissions or attempts)
    let active_days: Vec<(chrono::NaiveDate,)> = sqlx::query_as(
        "SELECT DISTINCT DATE(submitted_at) as day FROM attempts WHERE student_id = $1 AND submitted_at IS NOT NULL
         UNION
         SELECT DISTINCT DATE(submitted_at) as day FROM code_submissions WHERE student_id = $1
         ORDER BY day DESC"
    )
    .bind(user.id)
    .fetch_all(&state.db)
    .await?;

    let mut current_streak = 0i32;
    let mut longest_streak = 0i32;
    let mut streak = 0i32;
    let today = chrono::Utc::now().date_naive();

    for (i, (day,)) in active_days.iter().enumerate() {
        let expected = today - chrono::Duration::days(i as i64);
        if *day == expected {
            streak += 1;
            if i == 0 || streak > current_streak {
                current_streak = streak;
            }
        } else {
            longest_streak = longest_streak.max(streak);
            streak = 0;
        }
    }
    longest_streak = longest_streak.max(streak);

    Ok(Json(serde_json::json!({
        "student_id": user.id,
        "current_streak": current_streak,
        "longest_streak": longest_streak,
        "total_active_days": active_days.len()
    })))
}

pub async fn list_faqs(
    State(state): State<AppState>,
) -> Result<impl IntoResponse, AppError> {
    let faqs = sqlx::query_as::<_, Faq>(
        "SELECT * FROM faqs WHERE is_published = true ORDER BY sort_order ASC"
    )
    .fetch_all(&state.db)
    .await?;

    Ok(Json(faqs))
}
