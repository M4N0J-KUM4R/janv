use axum::{extract::{State, Multipart}, Json, response::IntoResponse, Extension};
use janv_common::{dto::*, errors::AppError, models::*};
use crate::{db::AppState, auth::middleware::AuthUser};

pub async fn bulk_import_users(
    State(state): State<AppState>,
    Extension(user): Extension<AuthUser>,
    mut multipart: Multipart,
) -> Result<impl IntoResponse, AppError> {
    // Basic multipart reading placeholder
    while let Some(field) = multipart.next_field().await.unwrap_or(None) {
        let _name = field.name().unwrap_or("").to_string();
        let _data = field.bytes().await.unwrap_or_default();
        // Parse CSV and insert
    }
    
    Ok(Json(serde_json::json!({"message": "Import initiated"})))
}
