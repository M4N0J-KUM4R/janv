use axum::{extract::State, Json, response::IntoResponse, Extension};
use janv_common::{dto::*, errors::AppError, models::*};
use crate::{db::AppState, auth::middleware::AuthUser};

pub async fn get_dashboard(
    State(state): State<AppState>,
    Extension(user): Extension<AuthUser>,
) -> Result<impl IntoResponse, AppError> {
    // Dummy query for stats
    let users_count: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM users")
        .fetch_one(&state.db)
        .await
        .unwrap_or((0,));
        
    Ok(Json(serde_json::json!({
        "total_users": users_count.0,
    })))
}
