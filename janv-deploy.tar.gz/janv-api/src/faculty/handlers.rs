use axum::{extract::State, Json, response::IntoResponse, Extension};
use janv_common::{dto::*, errors::AppError, models::*};
use crate::{db::AppState, auth::middleware::AuthUser};

pub async fn get_faculty_dashboard(
    State(state): State<AppState>,
    Extension(user): Extension<AuthUser>,
) -> Result<impl IntoResponse, AppError> {
    let courses_count: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM courses WHERE faculty_id = $1")
        .bind(user.id)
        .fetch_one(&state.db)
        .await
        .unwrap_or((0,));
        
    Ok(Json(serde_json::json!({
        "courses_count": courses_count.0,
    })))
}
